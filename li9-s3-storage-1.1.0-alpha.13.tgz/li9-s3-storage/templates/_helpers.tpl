{{- define "li9-s3.imageTag" -}}
{{- default .Chart.AppVersion .Values.images.tag -}}
{{- end -}}

{{- define "li9-s3.image" -}}
{{- $root := .root -}}
{{- $image := .image -}}
{{- printf "%s:%s-v%s" $root.Values.images.repository $image (include "li9-s3.imageTag" $root) -}}
{{- end -}}

{{- define "li9-s3.gatewayHost" -}}
{{- default (printf "s3-gateway.%s.svc.cluster.local" .Release.Namespace) .Values.gateway.host -}}
{{- end -}}

{{- define "li9-s3.gatewayURL" -}}
{{- printf "https://%s" (include "li9-s3.gatewayHost" .) -}}
{{- end -}}

{{- define "li9-s3.virtualHostSuffix" -}}
{{- default "" (default .Values.gateway.host .Values.gateway.virtualHostSuffix) -}}
{{- end -}}

{{- define "li9-s3.profile" -}}
{{- default "FullDistributed" .Values.profile -}}
{{- end -}}

{{- define "li9-s3.objectBackend" -}}
{{- $profile := include "li9-s3.profile" . -}}
{{- $configured := default "" .Values.storage.objectBackend.type -}}
{{- if $configured -}}
{{- $configured -}}
{{- else if eq $profile "S3OverPVC" -}}
Filesystem
{{- else -}}
StorageNodeErasure
{{- end -}}
{{- end -}}

{{- define "li9-s3.objectBackendEnv" -}}
{{- if eq (include "li9-s3.objectBackend" .) "Filesystem" -}}
filesystem
{{- else -}}
storage-node-erasure
{{- end -}}
{{- end -}}

{{- define "li9-s3.usesStorageNode" -}}
{{- if and (ne (include "li9-s3.profile" .) "S3PlaneOnly") (eq (include "li9-s3.objectBackend" .) "StorageNodeErasure") -}}true{{- end -}}
{{- end -}}

{{- define "li9-s3.usesFilesystemBackend" -}}
{{- if and (ne (include "li9-s3.profile" .) "S3PlaneOnly") (eq (include "li9-s3.objectBackend" .) "Filesystem") -}}true{{- end -}}
{{- end -}}

{{- define "li9-s3.serviceEnabled" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $profile := include "li9-s3.profile" $root -}}
{{- if eq $profile "StoragePlaneOnly" -}}
{{- if has $name (list "bucket-service" "metadata-service" "object-service" "kms-service" "healing-service" "audit-service") -}}true{{- end -}}
{{- else if eq $profile "S3PlaneOnly" -}}
{{- if has $name (list "s3-gateway" "control-api" "identity-service" "policy-service" "audit-service") -}}true{{- end -}}
{{- else -}}
{{- if has $name (list "s3-gateway" "control-api" "identity-service" "policy-service" "bucket-service" "metadata-service" "object-service" "kms-service" "healing-service" "audit-service") -}}true{{- end -}}
{{- end -}}
{{- if and (eq $name "storage-node") (include "li9-s3.usesStorageNode" $root) -}}true{{- end -}}
{{- end -}}

{{- define "li9-s3.storageNodeURLs" -}}
{{- $replicas := int (default 4 .Values.runtime.storageNodeReplicas) -}}
{{- $urls := list -}}
{{- range $i := until $replicas -}}
{{- $urls = append $urls (printf "https://storage-node-%d.storage-node-headless:8080" $i) -}}
{{- end -}}
{{- join "," $urls -}}
{{- end -}}

{{- define "li9-s3.metadataClaimName" -}}
{{- if eq (default "DedicatedPVC" .Values.storage.metadata.mode) "SharedDataPVC" -}}
{{- if include "li9-s3.usesFilesystemBackend" . -}}
{{- default "object-service-data" .Values.storage.objectBackend.pvcName -}}
{{- else -}}
storage-node-shared-data
{{- end -}}
{{- else -}}
{{- default "metadata-service-data" .Values.storage.metadata.pvcName -}}
{{- end -}}
{{- end -}}

{{- define "li9-s3.bucketServiceURL" -}}
{{- if eq (include "li9-s3.profile" .) "S3PlaneOnly" -}}
{{- required "storagePlane.bucketServiceURL is required when profile=S3PlaneOnly" .Values.storagePlane.bucketServiceURL -}}
{{- else -}}
https://bucket-service:8080
{{- end -}}
{{- end -}}

{{- define "li9-s3.objectServiceURL" -}}
{{- if eq (include "li9-s3.profile" .) "S3PlaneOnly" -}}
{{- required "storagePlane.objectServiceURL is required when profile=S3PlaneOnly" .Values.storagePlane.objectServiceURL -}}
{{- else -}}
https://object-service:8080
{{- end -}}
{{- end -}}

{{- define "li9-s3.internalDNSNames" -}}
{{- $ns := .Release.Namespace -}}
{{- $names := list
  "s3-gateway" (printf "s3-gateway.%s.svc" $ns) (printf "s3-gateway.%s.svc.cluster.local" $ns)
  "control-api" (printf "control-api.%s.svc" $ns) (printf "control-api.%s.svc.cluster.local" $ns)
  "identity-service" (printf "identity-service.%s.svc" $ns) (printf "identity-service.%s.svc.cluster.local" $ns)
  "policy-service" (printf "policy-service.%s.svc" $ns) (printf "policy-service.%s.svc.cluster.local" $ns)
  "bucket-service" (printf "bucket-service.%s.svc" $ns) (printf "bucket-service.%s.svc.cluster.local" $ns)
  "metadata-service" (printf "metadata-service.%s.svc" $ns) (printf "metadata-service.%s.svc.cluster.local" $ns)
  "object-service" (printf "object-service.%s.svc" $ns) (printf "object-service.%s.svc.cluster.local" $ns)
  "kms-service" (printf "kms-service.%s.svc" $ns) (printf "kms-service.%s.svc.cluster.local" $ns)
  "healing-service" (printf "healing-service.%s.svc" $ns) (printf "healing-service.%s.svc.cluster.local" $ns)
  "audit-service" (printf "audit-service.%s.svc" $ns) (printf "audit-service.%s.svc.cluster.local" $ns)
  "storage-node" (printf "storage-node.%s.svc" $ns) (printf "storage-node.%s.svc.cluster.local" $ns)
  "storage-node-headless" (printf "storage-node-headless.%s.svc" $ns) (printf "storage-node-headless.%s.svc.cluster.local" $ns)
  "storage-node-0.storage-node-headless" "storage-node-1.storage-node-headless" "storage-node-2.storage-node-headless" "storage-node-3.storage-node-headless"
  (printf "storage-node-0.storage-node-headless.%s.svc" $ns) (printf "storage-node-1.storage-node-headless.%s.svc" $ns) (printf "storage-node-2.storage-node-headless.%s.svc" $ns) (printf "storage-node-3.storage-node-headless.%s.svc" $ns)
  (printf "storage-node-0.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-1.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-2.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-3.storage-node-headless.%s.svc.cluster.local" $ns)
-}}
{{- toJson $names -}}
{{- end -}}
