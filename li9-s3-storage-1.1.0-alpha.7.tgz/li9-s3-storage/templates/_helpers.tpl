{{- define "li9-s3.imageTag" -}}
{{- default .Chart.AppVersion .Values.images.tag -}}
{{- end -}}

{{- define "li9-s3.image" -}}
{{- $root := .root -}}
{{- $image := .image -}}
{{- printf "%s:%s-v%s" $root.Values.images.repository $image (include "li9-s3.imageTag" $root) -}}
{{- end -}}

{{- define "li9-s3.gatewayHost" -}}
{{- default (printf "s3-gateway.%s.svc.cluster.local" .Release.Namespace) .Values.gateway.host -}}
{{- end -}}

{{- define "li9-s3.gatewayURL" -}}
{{- printf "https://%s" (include "li9-s3.gatewayHost" .) -}}
{{- end -}}

{{- define "li9-s3.virtualHostSuffix" -}}
{{- default "" (default .Values.gateway.host .Values.gateway.virtualHostSuffix) -}}
{{- end -}}

{{- define "li9-s3.internalDNSNames" -}}
{{- $ns := .Release.Namespace -}}
{{- $names := list
  "s3-gateway" (printf "s3-gateway.%s.svc" $ns) (printf "s3-gateway.%s.svc.cluster.local" $ns)
  "control-api" (printf "control-api.%s.svc" $ns) (printf "control-api.%s.svc.cluster.local" $ns)
  "identity-service" (printf "identity-service.%s.svc" $ns) (printf "identity-service.%s.svc.cluster.local" $ns)
  "policy-service" (printf "policy-service.%s.svc" $ns) (printf "policy-service.%s.svc.cluster.local" $ns)
  "bucket-service" (printf "bucket-service.%s.svc" $ns) (printf "bucket-service.%s.svc.cluster.local" $ns)
  "metadata-service" (printf "metadata-service.%s.svc" $ns) (printf "metadata-service.%s.svc.cluster.local" $ns)
  "object-service" (printf "object-service.%s.svc" $ns) (printf "object-service.%s.svc.cluster.local" $ns)
  "kms-service" (printf "kms-service.%s.svc" $ns) (printf "kms-service.%s.svc.cluster.local" $ns)
  "healing-service" (printf "healing-service.%s.svc" $ns) (printf "healing-service.%s.svc.cluster.local" $ns)
  "audit-service" (printf "audit-service.%s.svc" $ns) (printf "audit-service.%s.svc.cluster.local" $ns)
  "storage-node" (printf "storage-node.%s.svc" $ns) (printf "storage-node.%s.svc.cluster.local" $ns)
  "storage-node-headless" (printf "storage-node-headless.%s.svc" $ns) (printf "storage-node-headless.%s.svc.cluster.local" $ns)
  "storage-node-0.storage-node-headless" "storage-node-1.storage-node-headless" "storage-node-2.storage-node-headless" "storage-node-3.storage-node-headless"
  (printf "storage-node-0.storage-node-headless.%s.svc" $ns) (printf "storage-node-1.storage-node-headless.%s.svc" $ns) (printf "storage-node-2.storage-node-headless.%s.svc" $ns) (printf "storage-node-3.storage-node-headless.%s.svc" $ns)
  (printf "storage-node-0.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-1.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-2.storage-node-headless.%s.svc.cluster.local" $ns) (printf "storage-node-3.storage-node-headless.%s.svc.cluster.local" $ns)
-}}
{{- toJson $names -}}
{{- end -}}
